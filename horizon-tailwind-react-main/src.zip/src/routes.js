import React from "react";

// Admin Imports
//import MainDashboard from "views/admin/default";
import NFTMarketplace from "views/admin/marketplace";
import Home from "views/admin/default";
import Profile from "views/admin/profile";
import DataTables from "views/admin/tables";


// Icon Imports
import {
  //  MdHome,
  MdOutlineShoppingCart,
  MdBarChart,
  MdPerson,
  MdSettings,
  // MdLock,
} from "react-icons/md";

const routes = [
  // {
  //   name: "Main Dashboard",
  //   layout: "/admin",
  //   path: "default",
  //   icon: <MdHome className="h-6 w-6" />,
  //   component: <MainDashboard />,
  // },
  {
    name: "Home",
    layout: "/admin",
    path: "default",
    icon: <MdOutlineShoppingCart className="h-6 w-6" />,
    component: <Home />,
    secondary: true,
  },
  {
    name: "Message",
    layout: "/admin",
    path: "msg",
    icon: <MdBarChart className="h-6 w-6" />,
    component: <NFTMarketplace />,
    secondary: true,
  },
  {
    name: "Tasks",
    layout: "/admin",
    path: "tsk",
    icon: <MdPerson className="h-6 w-6" />,
    component: <NFTMarketplace />,
  },
  {
    name: "Members",
    layout: "/admin",
    path: "profile",
    icon: <MdPerson className="h-6 w-6" />,
    component: <Profile />,
  },
  {
    name: "Settings",
    layout: "/admin",
    path: "settings",
    icon: <MdSettings className="h-6 w-6" />,
    component: <Profile />,
  },
  <div class="mt-[58px] mb-7 h-px bg-gray-300 dark:bg-white/30" />
];
export default routes;
