import React from "react";

// Admin Imports
//import MainDashboard from "views/admin/default";
import New1 from "views/admin/new1";
import Profile from "views/admin/profile";
import DataTables from "views/admin/tables";

import MobileApp from "views/admin/mobileApp";
import WebsiteRedesign from "views/admin/websiteRedesign";
import DesignSystem from "views/admin/designSystem";
import WireFrames from "views/admin/wireFrames";
// Icon Imports

import {
  //  MdHome,
  MdOutlineShoppingCart,
  MdBarChart,
  MdPerson,
  MdSettings,
  // MdLock,
} from "react-icons/md";

const projects = [
  // {
  //   name: "Main Dashboard",
  //   layout: "/admin",
  //   path: "default",
  //   icon: <MdHome className="h-6 w-6" />,
  //   component: <MainDashboard />,
  // },
  {
    name: "Mobile App",
    layout: "/admin",
    path: "mobileApp",
    icon: <MdOutlineShoppingCart className="h-6 w-6" />,
    component: <MobileApp />,
    secondary: true,
  },
  {
    name: "Website Redesign",
    layout: "/admin",
    path: "websiteRedesign",
    icon: <MdOutlineShoppingCart className="h-6 w-6" />,
    component: <WebsiteRedesign />,
  },
  {
    name: "Design System",
    layout: "/admin",
    path: "designSystem",
    icon: <MdOutlineShoppingCart className="h-6 w-6" />,
    component: <DesignSystem />,
    secondary: true,
  },
  {
    name: "Wireframes",
    layout: "/admin",
    path: "wireFrames",
    icon: <MdOutlineShoppingCart className="h-6 w-6" />,
    component: <WireFrames />,
    secondary: true,
  },
  <div class="mt-[58px] mb-7 h-px bg-gray-300 dark:bg-white/30" />
];
export default projects;
